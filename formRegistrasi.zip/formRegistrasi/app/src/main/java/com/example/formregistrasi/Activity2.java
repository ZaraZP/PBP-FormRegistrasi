package com.example.formregistrasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    Bundle extras = getIntent().getExtras();
    String nama = extras.getString("nama");
    String tempat = extras.getString("tempat");
    String date = extras.getString("date");
    TextView datanama, datatempat, datattl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        datanama = findViewById(R.id.dataNama);
        datatempat = findViewById(R.id.datatempat);
        datattl = findViewById(R.id.datattl);
        datanama.setText(nama);
        datatempat.setText(tempat);
        datattl.setText(date);
    }
}