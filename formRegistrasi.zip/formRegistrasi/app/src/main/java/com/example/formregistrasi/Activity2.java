package com.example.formregistrasi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class Activity2 extends AppCompatActivity {


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Bundle extras = getIntent().getExtras();
        String nama = extras.getString("nama");
        String tempat = extras.getString("tempat");
        String date = extras.getString("date");
        TextView datanama, datatempat, datattl;
        datanama = findViewById(R.id.datanama);
        datatempat = findViewById(R.id.datatempat);
        datattl = findViewById(R.id.datattl);
        datanama.setText(nama);
        datatempat.setText(tempat);
        datattl.setText(date);

    }

}